/*****************************************************************************
 *   A demo example using several of the peripherals on the base board
 *
 *   Copyright(C) 2011, EE2024
 *   All rights reserved.
 *
 ******************************************************************************/
#include <stdio.h>
#include "LPC17xx.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_gpio.h"
#include "lpc17xx_i2c.h"
#include "lpc17xx_ssp.h"
#include "lpc17xx_timer.h"

#include "joystick.h"
#include "pca9532.h"
#include "acc.h"
#include "oled.h"
#include "rgb.h"
#include "temp.h"
#include "light.h"
#include "led7seg.h"
#include "lpc17xx_uart.h"
// mode state
int8_t DATEMODE = 0;
int8_t PASSIVEMODE = 0;
int8_t enterpassive = 0;
// SW4 button
int8_t SW4 = 0;
int8_t SW4now = 1;
int8_t SW4last = 1;
// SW3 button
int32_t SW3 = 0;
// accelermeter
int8_t x = 0;
int8_t y = 0;
int8_t z = 0;
// 7 segment display
int8_t sevensegment = 0;
int8_t SEVENsegmentTimer = 0;
// timer
int32_t initialticks = 0;
int32_t initial = 0;
int8_t ledinitial = 0;
//falgs
int8_t reset_initial = 0;
//counter
int8_t NNN = 000;
int8_t j=16;
int32_t lednum = 0xffff;
//RGB
int8_t BLINK_BLUE = 0;
int8_t BLINK_RED = 0;
int32_t ledstatered = 0;
int8_t rgbredtimer= 0;
int8_t rgbbluetimer= 0;
int8_t rgbtimer = 0;
int32_t rgbred, rgbblue, rgb;
//light sensor
int32_t light_val;
//TEMP SENSOR
int32_t temperature;
uint32_t temp_count = 0;
uint32_t temp_value = 0;
uint32_t T = 0;
int32_t t1=0;
int32_t t2=0;


volatile uint32_t msTicks; // counter for 1ms SysTicks

// ****************
//  SysTick_Handler - just increment SysTick counter
void SysTick_Handler(void) {
	msTicks++;
}

uint32_t getMsTicks (){
	return msTicks;
}

void pinsel_uart3(void){
	PINSEL_CFG_Type PinCfg;
	PinCfg. Funcnum = 2;
	PinCfg. Pinnum = 0;
	PinCfg. Portnum = 0;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg. Pinnum = 1;
	PINSEL_ConfigPin(&PinCfg);
}

void init_uart(void){
	UART_CFG_Type uartCfg;
	uartCfg. Baud_rate = 115200;
	uartCfg. Databits = UART_DATABIT_8;
	uartCfg. Parity = UART_PARITY_NONE;
	uartCfg. Stopbits = UART_STOPBIT_1;
	//pin select for uart3;
	pinsel_uart3();
	//supply power & setup working par.s for uart3
	UART_Init(LPC_UART3, &uartCfg);
	//enable transmit for uart3
	UART_TxCmd(LPC_UART3, ENABLE);
}

static void init_ssp(void)
{
	SSP_CFG_Type SSP_ConfigStruct;
	PINSEL_CFG_Type PinCfg;

	/*
	 * Initialize SPI pin connect
	 * P0.7 - SCK;
	 * P0.8 - MISO
	 * P0.9 - MOSI
	 * P2.2 - SSEL - used as GPIO
	 */
	PinCfg.Funcnum = 2;
	PinCfg.OpenDrain = 0;
	PinCfg.Pinmode = 0;
	PinCfg.Portnum = 0;
	PinCfg.Pinnum = 7;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 8;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 9;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Funcnum = 0;
	PinCfg.Portnum = 2;
	PinCfg.Pinnum = 2;
	PINSEL_ConfigPin(&PinCfg);

	SSP_ConfigStructInit(&SSP_ConfigStruct);

	// Initialize SSP peripheral with parameter given in structure above
	SSP_Init(LPC_SSP1, &SSP_ConfigStruct);

	// Enable SSP peripheral
	SSP_Cmd(LPC_SSP1, ENABLE);

}

static void init_i2c(void)
{
	PINSEL_CFG_Type PinCfg;

	/* Initialize I2C2 pin connect */
	PinCfg.Funcnum = 2;
	PinCfg.Pinnum = 10;
	PinCfg.Portnum = 0;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 11;
	PINSEL_ConfigPin(&PinCfg);

	// Initialize I2C peripheral
	I2C_Init(LPC_I2C2, 100000);

	/* Enable I2C1 operation */
	I2C_Cmd(LPC_I2C2, ENABLE);
}

static void init_GPIO(void)
{
	// Initialize button //P1.31 SW4 input
	PINSEL_CFG_Type PinCfg;
	PinCfg.Funcnum= 0;
	PinCfg.OpenDrain=0;
	PinCfg.Pinmode=0;
	PinCfg.Portnum=1;
	PinCfg.Pinnum=31;
	PINSEL_ConfigPin(&PinCfg);
	GPIO_SetDir(1, 1<<31, 0);

	// PIO1_5 >> P0.2 TEMP SENSOR
	PinCfg.Portnum=0;
	PinCfg.Pinnum=2;
	PINSEL_ConfigPin(&PinCfg);
	GPIO_SetDir(0, 1<<2, 0);

	// PIO2_5 >> P2.5 light sensor
	PinCfg.Portnum=2;
	PinCfg.Pinnum=5;
	PINSEL_ConfigPin(&PinCfg);
	GPIO_SetDir(2, 1<<5, 0);

	// SW3 GPIO interrupt PI02_9 >> P2.10
	PinCfg.Portnum = 2;
	PinCfg.Pinnum = 10;
	PINSEL_ConfigPin(&PinCfg);
	GPIO_SetDir(2, 1<<10, 0); // input = 0;
}

void EINT3_IRQHandler(void)
{
	// Determine whether GPIO Interrupt P2.10 has occurred
	if ((LPC_GPIOINT->IO2IntStatF>>10) & 0x1)  // P2.10 SW3 interrupt
	{   // set SW3 flag
		SW3 = 1;
		// Clear GPIO Interrupt P2.10
		LPC_GPIOINT->IO2IntClr = 1<<10;
	}
   // temp sensor interrupt
	if((LPC_GPIOINT->IO0IntStatR>>2) & 0x1){ // P0.2 temp interrupt
		temp_count++;
		if(temp_count == 340){
			t2 = getMsTicks();
			T = t2 - t1;
			temp_count = 0;
			t1 = getMsTicks();
		}
	}
	// Clear GPIO Interrupt P0.2
	LPC_GPIOINT->IO0IntClr = 1<<2;
}

uint32_t tempread (uint32_t period)
{
	return ( (2*1000*period) / (340* 2) - 2731 );
}

int main (void) {
// initialasation and enable
	init_i2c();
	init_ssp();
	init_GPIO();
	init_uart();
	pca9532_init();
	acc_init();
	oled_init();
	led7seg_init();
	rgb_init();
	light_enable();
	GPIO_SetDir( 0, (1<<2) , 0 );
	SysTick_Config(SystemCoreClock / 1000);
	light_setRange(LIGHT_RANGE_4000);
// characteristics declaration
	char TemPrintHead[20];
	sprintf(TemPrintHead, "T :\r\n");
	char LightPrintHead[20];
	sprintf(LightPrintHead, "L :\r\n");
	char AXHead[20];
	sprintf(AXHead, "AX:\r\n");
	char AYHead[20];
	sprintf(AYHead, "AY:\r\n");
	char AZHead[20];
	sprintf(AZHead, "AZ:\r\n");

	char datemode[20];
	sprintf(datemode, "MODE:DATE\r\n");
	char TemPrintHeadDATE[20];
	sprintf(TemPrintHeadDATE, "T :DATE MODE\r\n");
	char LightPrintHeadDATE[20];
	sprintf(LightPrintHeadDATE, "L :DATE MODE\r\n");
	char AXHeadDATE[20];
	sprintf(AXHeadDATE, "AX:DATE MODE\r\n");
	char AYHeadDATE[20];
	sprintf(AYHeadDATE, "AY:DATE MODE\r\n");
	char AZHeadDATE[20];
	sprintf(AZHeadDATE, "AZ:DATE MODE\r\n");

	char passive[20];
	sprintf(passive, "MODE:PASSIVE\r\n");
	char ENTERPASSIVE[30];
	sprintf(ENTERPASSIVE, "Entering PASSIVE Mode.\r\n");
	char PASSIVETODATE[46];
	sprintf(PASSIVETODATE, "Leaving PASSIVE Mode. Entering DATE Mode.\r\n");
	char solid[24];
	sprintf(solid, "Solid was Detected.\r\n");
	char algae[24];
	sprintf(algae, "Algae was Detected.\r\n");

		char TemPrint[20];
		char LightPrint[20];
		char AX[20];
		char AY[20];
		char AZ[20];
		char senserdata[50];

// initial stable state
	oled_clearScreen(OLED_COLOR_BLACK);
	led7seg_setChar(0xFF,TRUE);// clear 7 segment
	pca9532_setLeds(0x0000,0xffff); // clear 16 leds
// Enable temp sensor interrupt
	LPC_GPIOINT->IO0IntEnR |= 1<<2; //temp sensor P0.2
	NVIC_EnableIRQ(EINT3_IRQn);// Enable EINT3 interrupt
//get initial time before enter while loop
	initialticks = getMsTicks();
	initial = getMsTicks();
	rgbred = getMsTicks();
	rgbblue = getMsTicks();
	rgb = getMsTicks();

	while(1){
// read SW4 button only at rasing edge
		SW4now = (GPIO_ReadValue(1) >> 31) & 0x01;
		if (SW4now != SW4last){
			if (SW4now == 1)
				SW4 = 1;
			else
				SW4 = 0;
		}
		SW4last = SW4now;

// set passive mode falg when press SW4 before
		if ((SW4 == 1) && (PASSIVEMODE == 0)){
			PASSIVEMODE = 1;
			SEVENsegmentTimer = 0;
			enterpassive = 1;
			SW4 = 0;
		}
// increase 7 segmenttimer for passive mode
		if((PASSIVEMODE == 1) && (DATEMODE == 0)){
			if ((msTicks - initialticks) >= 1000){

				sevensegment = 1;
				// compare time different
				if (reset_initial == 1){
					SEVENsegmentTimer++;
					initialticks = getMsTicks();

				}
				else{
					SEVENsegmentTimer = 0;
				    initialticks = getMsTicks();
				    reset_initial = 1;
				}
  			}
	    }


// REB blink
				if((BLINK_BLUE == 1) && (BLINK_RED == 0) && (PASSIVEMODE == 1)){
					if( (msTicks - rgbblue) >= 333){
						if (rgbbluetimer == 0){
							GPIO_SetValue(0, (1<<26));
						    rgbbluetimer = 1;
						}else {
							GPIO_ClearValue(0, (1<<26));
							rgbbluetimer = 0;
						}
						rgbblue = getMsTicks();
					}
				}

			     if((BLINK_RED == 1) && (BLINK_BLUE == 0) && (PASSIVEMODE == 1)){
					if( (msTicks - rgbred) >= 333){
						if (rgbredtimer == 0){
							GPIO_SetValue( 2, (1<<0));
						    rgbredtimer = 1;
						}else {
							GPIO_ClearValue( 2, (1<<0));
							rgbredtimer = 0;
						}
						rgbred = getMsTicks();
					}
				}

				if((BLINK_BLUE == 1) && (BLINK_RED == 1) && (PASSIVEMODE == 1)){
					if( (msTicks - rgb) >= 333){
						if (rgbtimer == 0){
							GPIO_SetValue( 0, (1<<26));
							GPIO_SetValue( 2, (1<<0));
						    rgbtimer = 1;
						}else {
							GPIO_ClearValue( 0, (1<<26));
							GPIO_ClearValue( 2, (1<<0));
							rgbtimer = 0;
						}
						rgb = getMsTicks();
					}
				}

if (sevensegment == 1 ){
	sevensegment =0;
	switch (SEVENsegmentTimer)
							{
							case 0:{
								light_val = light_read();// light sensor read value
								temp_value = tempread (T);
								acc_read(&x, &y, &z);
								if (enterpassive == 1){
									led7seg_setChar(0x24,TRUE); //0   bit==0 -> turn on ; bit == 1-> turn off
									oled_clearScreen(OLED_COLOR_BLACK);
									if ((light_val > 50) && (light_val < 1000)){
										BLINK_BLUE = 1;
										rgbbluetimer = 1;
									}

									if ((light_val < 50)){
										BLINK_RED = 1;
										rgbredtimer = 1;
									}
									sprintf(TemPrint, "T :%f\r\n", temp_value/10.0);
									sprintf(LightPrint, "L :%i lux\r\n.", light_val);
									sprintf(AX, "AX:%d\r\n",x);
									sprintf(AY, "AY:%d\r\n",y);
									sprintf(AZ, "AZ:%d\r\n",z);
									sprintf(senserdata,"%03d_-_T%f_L%i_AX%d_AY%d_AZ%d\r\n", NNN, temp_value/10.0, light_val, x, y, z);

									oled_putString(10, 1, (uint8_t*)passive, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
									oled_putString(0, 15, (uint8_t*)TemPrintHead, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
									oled_putString(0, 25, (uint8_t*)LightPrintHead, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
									oled_putString(0, 35, (uint8_t*)AXHead, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
									oled_putString(0, 45, (uint8_t*)AYHead, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
									oled_putString(0, 55, (uint8_t*)AZHead, OLED_COLOR_WHITE, OLED_COLOR_BLACK);

									UART_Send(LPC_UART3, (uint8_t *) ENTERPASSIVE, strlen(ENTERPASSIVE), BLOCKING);
									reset_initial = 1;
									enterpassive = 0;


								}

								if ((PASSIVEMODE == 1) && (DATEMODE == 0) && (enterpassive == 0)){
									led7seg_setChar(0x24,TRUE); //0   bit==0 -> turn on ; bit == 1-> turn off
									reset_initial = 1;
								}
								if ((SW4 == 1) && (PASSIVEMODE == 1)){
										DATEMODE = 1;
										SW4 = 0;
							    }
							}
							break;

							case 1:{
								led7seg_setChar(0x7D,TRUE);//1

							}
							break;

							case 2:{
								led7seg_setChar(0xE0,TRUE);//2

							}
							break;

							case 3:{
								led7seg_setChar(0x70,TRUE);//3
							}
							break;

							case 4:{
								led7seg_setChar(0x39,TRUE);//4
							}
							break;

							case 5:{
								light_val = light_read();// light sensor read value
								temp_value = tempread (T);
								acc_read(&x, &y, &z);
								led7seg_setChar(0x32,TRUE);//5

								if ((light_val > 50) && (light_val < 1000)){
									BLINK_BLUE = 1;
									rgbbluetimer = 1;
								}

								if ((light_val < 50) ){
									BLINK_RED = 1;
									rgbredtimer = 1;
								}
								sprintf(TemPrint, "T :%f\r\n", temp_value/10.0);
								sprintf(LightPrint, "L :%i lux\r\n.", light_val);
								sprintf(AX, "AX:%d\r\n",x);
								sprintf(AY, "AY:%d\r\n",y);
								sprintf(AZ, "AZ:%d\r\n",z);
								sprintf(senserdata,"%03d_-_T%f_L%i_AX%d_AY%d_AZ%d\r\n", NNN, temp_value/10.0, light_val, x, y, z);

								oled_putString(10, 1, (uint8_t*)passive, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
								oled_putString(0, 15, (uint8_t*)TemPrint, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
								oled_putString(0, 25, (uint8_t*)LightPrint, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
								oled_putString(0, 35, (uint8_t*)AX, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
								oled_putString(0, 45, (uint8_t*)AY, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
								oled_putString(0, 55, (uint8_t*)AZ, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
                                // check light_val and set blink flags

							}
							break;

							case 6:{
								led7seg_setChar(0x22,TRUE);//6
							}
							break;

							case 7:{
								led7seg_setChar(0x7C,TRUE);//7
							}
							break;

							case 8:{
								led7seg_setChar(0x20,TRUE);//8
							}
							break;

							case 9:{
								led7seg_setChar(0x30,TRUE);//9
							}
							break;

							case 10:{
								light_val = light_read();// light sensor read value
								temp_value = tempread (T);
								acc_read(&x, &y, &z);
								led7seg_setChar(0x28,TRUE);//A
								if ((light_val > 50) && (light_val < 1000)){
									BLINK_BLUE = 1;
									rgbbluetimer = 1;
								}

								if ((light_val < 50)){
									BLINK_RED = 1;
									rgbredtimer = 1;
								}
								sprintf(TemPrint, "T :%f\r\n", temp_value/10.0);
								sprintf(LightPrint, "L :%i lux\r\n.", light_val);
								sprintf(AX, "AX:%d\r\n",x);
								sprintf(AY, "AY:%d\r\n",y);
								sprintf(AZ, "AZ:%d\r\n",z);
								sprintf(senserdata,"%03d_-_T%f_L%i_AX%d_AY%d_AZ%d\r\n", NNN, temp_value/10.0, light_val, x, y, z);

								oled_putString(10, 1, (uint8_t*)passive, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
								oled_putString(0, 15, (uint8_t*)TemPrint, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
								oled_putString(0, 25, (uint8_t*)LightPrint, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
								oled_putString(0, 35, (uint8_t*)AX, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
								oled_putString(0, 45, (uint8_t*)AY, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
								oled_putString(0, 55, (uint8_t*)AZ, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
								// check light_val and set blink flags
							}
							break;

							case 11:{
								led7seg_setChar(0x20,TRUE);//B
							}
							break;

							case 12:{
								led7seg_setChar(0xA6,TRUE);//C
							}
							break;

							case 13:{
								led7seg_setChar(0x24,TRUE);//D
							}
							break;

							case 14:{
								led7seg_setChar(0xA2,TRUE);//E

							}
							break;

							case 15: {
								light_val = light_read();// light sensor read value
								temp_value = tempread (T);
								acc_read(&x, &y, &z);
								led7seg_setChar(0xAA,TRUE);//F
								if ((light_val > 50) && (light_val < 1000)){
									BLINK_BLUE = 1;
									rgbbluetimer = 1;
								}

								if ((light_val < 50)){
									BLINK_RED = 1;
									rgbredtimer = 1;
								}
								sprintf(TemPrint, "T :%f\r\n", temp_value/10.0);
								sprintf(LightPrint, "L :%i lux\r\n.", light_val);
								sprintf(AX, "AX:%d\r\n",x);
								sprintf(AY, "AY:%d\r\n",y);
								sprintf(AZ, "AZ:%d\r\n",z);
								sprintf(senserdata,"%03d_-_T%f_L%i_AX%d_AY%d_AZ%d\r\n", NNN, temp_value/10.0, light_val, x, y, z);

								oled_putString(10, 1, (uint8_t*)passive, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
								oled_putString(0, 15, (uint8_t*)TemPrint, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
								oled_putString(0, 25, (uint8_t*)LightPrint, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
								oled_putString(0, 35, (uint8_t*)AX, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
								oled_putString(0, 45, (uint8_t*)AY, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
								oled_putString(0, 55, (uint8_t*)AZ, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
								// check light_val and set blink flags


									// send data to CARE

									if (BLINK_BLUE == 1){
										UART_Send(LPC_UART3, (uint8_t *) algae, strlen(algae), BLOCKING);
									}

									if (BLINK_RED == 1){
										UART_Send(LPC_UART3, (uint8_t *) solid, strlen(solid), BLOCKING);
									}

									UART_Send(LPC_UART3, (uint8_t *) senserdata, strlen(senserdata), BLOCKING);
									NNN++;
									reset_initial = 0;


							}
							break;

							default: {
								break;
							}
}

}



// DATEMODE == 1 >> enter date mode
		if (DATEMODE == 1){// Enable GPIO Interrupt P2.10
		LPC_GPIOINT->IO2IntEnF |= 1<<10; //SW3 P2.10
		NVIC_EnableIRQ(EINT3_IRQn);// Enable EINT3 interrupt
		oled_clearScreen(OLED_COLOR_BLACK);
		led7seg_setChar(0xFF,TRUE); // clear 7 segment
		rgb_off ();
		BLINK_BLUE = 0;
		BLINK_RED = 0;
		oled_putString(10, 1, (uint8_t*)datemode, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
		oled_putString(0, 15, (uint8_t*)TemPrintHeadDATE, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
		oled_putString(0, 25, (uint8_t*)LightPrintHeadDATE, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
		oled_putString(0, 35, (uint8_t*)AXHeadDATE, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
		oled_putString(0, 45, (uint8_t*)AYHeadDATE, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
		oled_putString(0, 55, (uint8_t*)AZHeadDATE, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
		UART_Send(LPC_UART3, (uint8_t *) PASSIVETODATE, strlen(PASSIVETODATE), BLOCKING);
		pca9532_init();
		j = 16;
		lednum = 0xffff;
		while(j >= 0){
			if (SW3 == 1){
				light_val = light_read();// light sensor read value
				temp_value = tempread (T);
				acc_read(&x, &y, &z);
				oled_clearScreen(OLED_COLOR_BLACK);
				sprintf(TemPrint, "T :%f\r\n", temp_value/10.0);
				sprintf(LightPrint, "L :%i lux\r\n.", light_val);
				sprintf(AX, "AX:%d\r\n",x);
				sprintf(AY, "AY:%d\r\n",y);
				sprintf(AZ, "AZ:%d\r\n",z);
				sprintf(senserdata,"%03d_-_T%f_L%i_AX%d_AY%d_AZ%d\r\n", NNN, temp_value/10.0, light_val, x, y, z);
				oled_putString(10, 1, (uint8_t*)datemode, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
				oled_putString(0, 15, (uint8_t*)TemPrint, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
				oled_putString(0, 25, (uint8_t*)LightPrint, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
				oled_putString(0, 35, (uint8_t*)AX, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
				oled_putString(0, 45, (uint8_t*)AY, OLED_COLOR_WHITE, OLED_COLOR_BLACK);
				oled_putString(0, 55, (uint8_t*)AZ, OLED_COLOR_WHITE, OLED_COLOR_BLACK);

				UART_Send(LPC_UART3, (uint8_t *) senserdata, strlen(senserdata), BLOCKING);
				NNN++;
				SW3 = 0;
			}
			if((msTicks - initial) >= 208){
				pca9532_setLeds(lednum, 0xffff);
				initial = getMsTicks();
				lednum = lednum << 1;
				j--;
			}
		}
		oled_clearScreen(OLED_COLOR_BLACK);
		DATEMODE = 0;
		PASSIVEMODE = 1;
		enterpassive = 1;
		reset_initial = 0;
		NVIC_DisableIRQ(EINT3_IRQn);
		}
	}
	return 0;
}



void check_failed(uint8_t *file, uint32_t line)
{
	/* User can add his own implementation to report thNe file name and line number,
	 ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

	/* Infinite loop */
	while(1);
}


