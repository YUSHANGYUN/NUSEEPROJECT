/*****************************************************************************
 *   rgb.c:  Driver for the RGB LED
 *
 *   Copyright(C) 2009, Embedded Artists AB
 *   All rights reserved.
 *
 ******************************************************************************/

/******************************************************************************
 * Includes
 *****************************************************************************/

#include "lpc17xx_gpio.h"
#include "rgb.h"

/******************************************************************************
 * Defines and typedefs
 *****************************************************************************/

/******************************************************************************
 * External global variables
 *****************************************************************************/

/******************************************************************************
 * Local variables
 *****************************************************************************/

/******************************************************************************
 * Local Functions
 *****************************************************************************/

/******************************************************************************
 * Public Functions
 *****************************************************************************/

/******************************************************************************
 *
 * Description:
 *    Initialize RGB driver
 *
 *****************************************************************************/
void rgb_init (void)
{
    GPIO_SetDir( 2, (1<<0), 1 );
    GPIO_SetDir( 0, (1<<26), 1 );
  //  GPIO_SetDir( 2, (1<<1), 1 );

}

void rgb_off (void)
{
	GPIO_ClearValue( 0, (1<<26) );
	GPIO_ClearValue( 2, (1<<0));

}

void blue_on (void)
{
	GPIO_SetValue( 0, (1<<26) );
}

void blue_off (void)
{
	GPIO_ClearValue( 0, (1<<26) );
}

void red_on (void)
{
	GPIO_SetValue( 2, (1<<0));
}

void red_off (void)
{
	GPIO_ClearValue( 2, (1<<0));
}

void rgb_invertblue (void)
{
int ledstateblue;

ledstateblue = GPIO_ReadValue(0);

GPIO_ClearValue(0, 1<<26);

GPIO_SetValue(0, 1<<26);
}

/*
void rgb_invertred (void){

int ledstatered;

ledstatered = GPIO_ReadValue(2);

GPIO_ClearValue(2, (1<<0));

GPIO_SetValue(2, (1<<0));

}*/

/******************************************************************************
 *
 * Description:
 *    Set LED states
 *
 * Params:
 *    [in]  ledMask  - The mask is used to turn LEDs on or off
 *
 *****************************************************************************/
/*void rgb_setLeds (uint8_t ledMask)
{
    if ((ledMask & RGB_RED) != 0) {
        GPIO_SetValue( 2, 0);
    } else {
        GPIO_ClearValue( 2, 0 );
    }

    if ((ledMask & RGB_BLUE) != 0) {
        GPIO_SetValue( 0, (1<<26) );
    } else {
        GPIO_ClearValue( 0, (1<<26) );
    }

    if ((ledMask & RGB_GREEN) != 0) {
        GPIO_SetValue( 2, (1<<1) );
    } else {
        GPIO_ClearValue( 2, (1<<1) );
    }

}
*/
